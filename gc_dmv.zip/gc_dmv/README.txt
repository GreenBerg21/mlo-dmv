COPYRIGHTS
==============================================================================================================

Mapping is the property of GreenCom'e Mapping, all rights reserved. Available for download and personal use.
After downloading you can use the mapping for gaming and entertainment purposes. 
It is NOT PERMITTED to pass off mapping as your own, sell on third-party resources, transfer mapping to a third party in any of the formats for profit. 
If you have conflicts with other modifications from this modification - you can delete the modification. 
If the modification affects the performance of your server - you can remove the modification.
On this mapping there is partial support from the administration of the studio, as mapping is free any requests for it gets in the queue about processed without priority. 
If you have any wishes to change this modification and / or priority tasks - we will be happy to help you for a donation for our studio.


Requirements
==============================================================================================================

FIVEM Server
Gamebuild 2545+

==============================================================================================================